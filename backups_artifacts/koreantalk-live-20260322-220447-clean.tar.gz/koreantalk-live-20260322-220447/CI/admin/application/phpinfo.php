<?php
echo phpinfo();
?>
