<?php
	phpinfo();
?>
